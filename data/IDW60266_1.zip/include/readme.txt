The zip file contains spatial data (GML 2.1 and ESRI Shapefiles) of all the components of a Tropical Cyclone
Forecast Track Map. Metadata (ISO 19115) is available at http://reg.bom.gov.au/reguser/by_prod/metadata/tropical_cyclone.xml. 
The Bureau of Meteorology symbology for the shapefiles is contained in the subfolder, lyr_v9.1. The layer files can be used 
in ESRI ArcGIS version 9.x software. To obtain the best representation, activate the symbol levels. 
